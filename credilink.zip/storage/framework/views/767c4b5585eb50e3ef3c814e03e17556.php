<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'type' => 'success',
    'duration' => 4000,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'type' => 'success',
    'duration' => 4000,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $class = match ($type) {
        'success' => 'bg-green-50 text-green-800',
        'info' => 'bg-blue-50 text-blue-800',
        'danger' => 'bg-red-50 text-red-800',
        'warning' => 'bg-yellow-50 text-yellow-800',
        default => 'bg-blue-50 text-blue-800 dark:text-blue-400',
    };
?>

<div x-data="{ show: false }" 
    x-init="requestAnimationFrame(() => show = true); 
    setTimeout(() => show = false, <?php echo e($duration); ?>)" 
    x-show="show" 
    x-transition:enter="transition ease-out duration-500"
    x-transition:enter-start="opacity-0 translate-y-2" x-transition:enter-end="opacity-100 translate-y-0"
    x-transition:leave="transition ease-in duration-500" x-transition:leave-start="opacity-100 translate-y-0"
    x-transition:leave-end="opacity-0 translate-y-2"
    <?php echo e($attributes->merge(['class' => "alert fixed top-2 left-2 right-2 z-10 inline-flex items-center justify-between gap-2 p-4 mb-4 text-sm rounded-lg font-semibold $class"])); ?>

    role="alert">
    <?php echo e($slot); ?>


    <svg viewBox="0 0 20 20" fill="currentColor" data-slot="icon" aria-hidden="true" class="size-5 cursor-pointer" x-on:click="show = false">
        <path
            d="M6.28 5.22a.75.75 0 0 0-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 1 0 1.06 1.06L10 11.06l3.72 3.72a.75.75 0 1 0 1.06-1.06L11.06 10l3.72-3.72a.75.75 0 0 0-1.06-1.06L10 8.94 6.28 5.22Z">
        </path>
    </svg>
</div>
<?php /**PATH C:\xampp\htdocs\laravel\credilink-laravel\resources\views/components/alert.blade.php ENDPATH**/ ?>