<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white rounded-xl px-4 py-3 mb-3 flex gap-2 justify-end items-stretch">
        

        <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['href' => ''.e(route('clients')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('clients')).'']); ?>
            ← Volver
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
    </div>

    <div class="bg-white rounded-xl px-4 py-8">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight mb-5">
            Créditos de <?php echo e($client->name); ?>

        </h2>


        <!-- Credits List -->
        <div id="creditsList" class="space-y-4 mb-8">
            <?php $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php
                    switch ($credit->status) {
                        case 'pending':
                            $class = 'gradient-yellow';
                            $text = 'Pendiente';
                            break;

                        case 'approved':
                            $class = 'gradient-blue';
                            $text = 'Aprovado';
                            break;

                        case 'rejected':
                            $class = 'gradient-red';
                            $text = 'Rechazado';
                            break;

                        case 'paid':
                            $class = 'gradient-green';
                            $text = 'Pagado';
                            break;

                        default:
                            break;
                    }
                ?>

                <a href="<?php echo e(route('client.payments', $credit)); ?>"
                    class="<?php echo e($class); ?> block rounded-xl p-5 sm:p-6 text-white shadow-lg cursor-pointer hover:shadow-xl transition-shadow credit-card">
                    <!-- Versión móvil simplificada -->
                    <div class="block sm:hidden md:block lg:hidden">
                        <div class="flex justify-between items-start">
                            <div>
                                <h3 class="text-xl font-bold">Credito #<?php echo e($credit->id); ?></h3>
                                <p class="text-xs opacity-90 italic">Finaliza el <?php echo e($credit->end_date); ?></p>
                            </div>
                            <div class="text-right">
                                <p class="text-xs opacity-90">Monto Total</p>
                                <p class="font-bold text-lg">S/. <?php echo e($credit->amount); ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Versión desktop completa -->
                    <div class="hidden sm:flex sm:items-center sm:gap-8 md:hidden lg:flex">
                        <div>
                            <h3 class="text-2xl font-bold">Credito #<?php echo e($credit->id); ?></h3>
                            <p class="text-sm opacity-90 italic">Finaliza el <?php echo e($credit->end_date); ?></p>
                        </div>

                        <div class="h-12 w-px bg-white/30"></div>

                        <div class="flex gap-6">
                            <div>
                                <p class="text-sm opacity-90">Plazo</p>
                                <p class="font-bold text-base"><?php echo e($credit->term_months); ?> meses</p>
                            </div>
                            <div>
                                <p class="text-sm opacity-90">Estado</p>
                                <p class="font-bold text-base">
                                    <?php echo e($text); ?>

                                </p>
                            </div>
                            <div>
                                <p class="text-sm opacity-90">Saldo Pagado</p>
                                <p class="font-bold text-base"><?php echo e($credit->paid_balance); ?></p>
                            </div>
                            <div>
                                <p class="text-sm opacity-90">Monto Total</p>
                                <p class="font-bold text-base">S/. <?php echo e($credit->amount); ?></p>
                            </div>
                        </div>
                    </div>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- Credito #3 - Activo (Azul) -->
            
        </div>


    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\credilink-laravel\resources\views/credits.blade.php ENDPATH**/ ?>