<!DOCTYPE html>
<html lang="pe">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/login.css'); ?>
</head>

<body>



    <header class="block-1">
        <img src="<?php echo e(asset('img/login/logo.webp')); ?>" alt="Logo">
    </header>

    <section class="block-2">
        <div class="card">
            <div>
                <img src="<?php echo e(asset('img/login/creditos.webp')); ?>" alt="creditos">
                <p>Créditos Rápidos</p>
            </div>
            <div>
                <img src="<?php echo e(asset('img/login/pagos.webp')); ?>" alt="pagos">
                <p>Pagos Rápidos</p>
            </div>
            <div>
                <img src="<?php echo e(asset('img/login/prestamos.webp')); ?>" alt="prestamos">
                <p>Préstamos sin intereses</p>
            </div>
            <div>
                <img src="<?php echo e(asset('img/login/seguridad.webp')); ?>" alt="seguridad">
                <p>Máxima Seguridad</p>
            </div>
        </div>

        <div class="card-2">
            <div class="form">
                <div>
                    <h1>Sistema de Entidad Financiera</p>
                </div>
                <div>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <!-- Email -->
                        <div>
                            <label for="email">Correo</label><br>
                            <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" required
                                autofocus autocomplete="username">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div><br><br>

                        <!-- Password -->
                        <div>
                            <label for="password">Contraseña</label><br>
                            <input id="password" type="password" name="password" required
                                autocomplete="current-password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div style="color: red;"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if(session('error')): ?>
                                <div style="color: red;">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <br><br>
                        <!-- Submit -->
                        <div class="buttons">
                            <div class="buttons-social">
                                <a href="<?php echo e(route('auth.google')); ?>" class="button-google">
                                    <img src="<?php echo e(asset('img/login/google.webp')); ?>" alt="google">
                                    <p>Iniciar Sesión Google</p>
                                </a>
                                <a href="<?php echo e(route('auth.github')); ?>" class="button-github">
                                    <img src="<?php echo e(asset('img/login/github.webp')); ?>" alt="github">
                                    <p>Iniciar Sesión GitHub</p>
                                </a>
                            </div>
                            <div class="button-submit">
                                <button type="submit">
                                    Entrar
                                    <img src="<?php echo e(asset('img/login/entrar.webp')); ?>" alt="entrar">

                                </button>
                            </div>
                        </div>
                        <?php $__errorArgs = ['social_errors'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div style="color: red; margin-top: .5rem;"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </form>
                </div>
            </div>
            <div class="card-img">
                <img src="<?php echo e(asset('img/login/imagen.webp')); ?>" alt="imagen">
                <img src="<?php echo e(asset('img/login/logo 2.webp')); ?>" alt="logo 2">
            </div>
        </div>

        <div class="line">

        </div>
    </section>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\credilink-laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>