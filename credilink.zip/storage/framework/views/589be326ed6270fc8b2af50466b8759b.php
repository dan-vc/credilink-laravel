
<img src="<?php echo e(asset('img/dashboard/logo.png')); ?>" alt="CrediLink Logo">
<?php /**PATH C:\xampp\htdocs\laravel\credilink-laravel\resources\views/components/application-logo.blade.php ENDPATH**/ ?>