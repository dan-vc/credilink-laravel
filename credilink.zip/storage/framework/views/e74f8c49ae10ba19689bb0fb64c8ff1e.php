<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white rounded-xl px-4 py-8 font-medium">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight mb-5">
            Reportes - Resumen General
        </h2>

        <div class="grid sm:grid-cols-2 xl:grid-cols-4 gap-5 items-stretch mb-5">
            <div class="p-5 flex flex-col justify-between border border-gray-300 rounded-lg">
                <h3 class="mb-2">
                    Total de créditos activos
                </h3>
                <span class="text-4xl font-bold">
                    <?php echo e($totalCredits); ?>

                </span>
            </div>
            <div class="p-5 flex flex-col justify-between border border-gray-300 rounded-lg">
                <h3 class="mb-2">
                    Total de clientes
                </h3>
                <span class="text-4xl font-bold">
                    <?php echo e($clients->total()); ?>

                </span>
            </div>
            <div class="p-5 flex flex-col justify-between border border-gray-300 rounded-lg">
                <h3 class="mb-2">
                    Créditos vencidos
                </h3>
                <span class="text-4xl font-bold">
                    <?php echo e($dueCredits); ?>

                </span>
            </div>
            <div class="p-5 flex flex-col justify-between border border-gray-300 rounded-lg">
                <h3 class="mb-2">
                    Pagos recibidos este mes
                </h3>
                <span class="text-4xl font-bold">
                    <?php echo e($totalPayments); ?>

                </span>
            </div>
        </div>

        <div class="p-3 sm:p-5 border border-gray-300 rounded-lg mb-5">
            <h3 class="mb-2">Créditos otorgados este mes</h3>

            <div class="aspect-square sm:aspect-auto sm:h-[460px]">
                <?php if (isset($component)) { $__componentOriginal6675c8df65c3da24f83d21e6b6c7d707 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707 = $attributes; } ?>
<?php $component = IcehouseVentures\LaravelChartjs\View\Components\ChartjsComponent::resolve(['chart' => $chart] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('chartjs-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\IcehouseVentures\LaravelChartjs\View\Components\ChartjsComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707)): ?>
<?php $attributes = $__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707; ?>
<?php unset($__attributesOriginal6675c8df65c3da24f83d21e6b6c7d707); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6675c8df65c3da24f83d21e6b6c7d707)): ?>
<?php $component = $__componentOriginal6675c8df65c3da24f83d21e6b6c7d707; ?>
<?php unset($__componentOriginal6675c8df65c3da24f83d21e6b6c7d707); ?>
<?php endif; ?>
            </div>
        </div>

        <div class="p-3 sm:p-5 border border-gray-300 rounded-lg">
            <h3 class="mb-2">Reporte de Clientes</h3>
            <div class="relative overflow-x-auto flex">
                <table class="w-full min-w-max text-sm text-left text-gray-800 font-medium">
                    <thead class="text-gray-400 fontP-medium border-b border-gray-200">
                        <tr>
                            <th scope="col" class="p-3 font-medium">Nombre</th>
                            <th scope="col" class="p-3 font-medium">Teléfono</th>
                            <th scope="col" class="p-3 font-medium">Correo electrónico</th>
                            <th scope="col" class="p-3 font-medium">Total de Créditos</th>
                            <th scope="col" class="p-3 font-medium">Total Adeudado</th>
                            <th scope="col" class="p-3 font-medium">Estado</th>
                            <th scope="col" class="p-3 font-medium">Creado por</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="bg-white border-b border-gray-200 filter-item">
                                <td class="px-3 py-4">
                                    <?php echo e($client->name); ?>

                                </td>
                                <td class="px-3 py-4">
                                    <?php echo e($client->phone); ?>

                                </td>
                                <td class="px-3 py-4">
                                    <?php echo e($client->email); ?>

                                </td>
                                <td class="px-3 py-4">
                                    <?php echo e($client->credits->count()); ?>

                                </td>
                                <td class="px-3 py-4">
                                    S/. <?php echo e(number_format($client->credits->sum('amount'), 2, '.', ',')); ?>

                                </td>
                                <td class="px-3 py-4">
                                    <?php switch($client->status):
                                        case ('active'): ?>
                                            <span
                                                class="bg-green-100 border border-green-700 text-green-800 px-3 py-1 rounded-md">
                                                Activo
                                            </span>
                                        <?php break; ?>

                                        <?php case ('inactive'): ?>
                                            <span class="bg-red-100 border border-red-700 text-red-800 px-3 py-1 rounded-md">
                                                Inactivo
                                            </span>
                                        <?php break; ?>

                                        <?php default: ?>
                                    <?php endswitch; ?>
                                </td>
                                <td class="px-3 py-4">
                                    <span class="underline"><?php echo e($client->creator->name); ?></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php echo e($clients->links()); ?>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\credilink-laravel\resources\views/reports.blade.php ENDPATH**/ ?>